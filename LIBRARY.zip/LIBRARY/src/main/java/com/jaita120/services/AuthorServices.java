package com.jaita120.services;

import java.util.List;

import com.jaita120.entities.Author;

public interface AuthorServices {

List <Author> findAll();
	
	
	//Aggiungo metodo che restituisce author di cui si conosce l'id
	Author findById(Integer id) throws Exception;
	
	
	//salva un nuovo author
	Author save(Author author) ;
	
	
	//Cancella un author di id specificato
	void deleteById(Integer id) throws Exception;
	
	//completare gli altri metodi crud
	
	Author updateById(Integer id, Author Author) throws Exception;
	
	
	// Cerca un author con un dato nome e cognome
		Author findByNameAndSurname(String name, String surname) throws Exception;
	
	
	
	
	
	
	
	
}
