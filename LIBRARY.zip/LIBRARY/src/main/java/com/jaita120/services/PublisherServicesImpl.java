package com.jaita120.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jaita120.entities.Publisher;
import com.jaita120.repositories.PublisherRepository;

@Service
public class PublisherServicesImpl implements PublisherServices {
	
	
	
	@Autowired
	private PublisherRepository repository;

	@Override
	public List<Publisher> findAll() {
		return (List <Publisher>)repository.findAll();
	}

	@Override
	public Publisher findById(Integer id) throws Exception {
		Optional <Publisher> optPublisher = repository.findById(id);
		if(optPublisher.isPresent()) {
			return optPublisher.get();
		}
		throw new Exception ("Publisher with id" +id + "not exists");
	}

	@Override
	public Publisher save(Publisher publisher) {
		
			return repository.save(publisher);
		
	}

	@Override
	public void deleteById(Integer id) throws Exception {
		if(repository.existsById(id)) {
			repository.deleteById(id);
		}
		else {
			throw new Exception("id not found");
		}
		
	}

	@Override
	public Publisher updateById(Integer id, Publisher Publisher) throws Exception {
		
		if(repository.existsById(id)) {
			return repository.save(Publisher);
		}
		
		else {		
			throw new Exception ("Publisher with id" +id + "not exists");

			
		}
	}

	@Override
	public Publisher findByName(String name) throws Exception {
		Optional<Publisher> optPublisher = repository.findByName(name);
		if (optPublisher.isPresent()) {
			return optPublisher.get();
		}
		throw new Exception("Publisher with name " + name +" not exists");
	}
	}





/*
 * Implementa i metodi dell'interfaccia publisherServices,
 * 
 * @Service = indica che questa classe è un servizio,un componente della logica 
 * 
 * @Autowired = Utilizzata per iniettare automaticamente una dipendenza. Spring inietta un'istanza della classe
 * PublishedRepository nella variabile repository
 * 
 * private PublisherRepository repository: definisce una variabile di istanza che rappresenta il repository utilizzato 
 * per accedere ai dati del "Publisher"
 * 
 * @Override = significa che questo metodo sta sovrascrivendo un metodo dell'interfaccia PublisherServices
 * 
 * return (List<Publisher>) repository.findAll(): Chiama il metodo findAll() del repository,
 *  che restituisce tutti i Publisher presenti nel database. Il risultato viene castato a List<Publisher> e poi restituito.
 * 
 * 
 * API = APPLICATION PROGRAMMING INTERFACE. 
 * 
 * 
 */

