package com.jaita120.services;

import java.util.List;





import com.jaita120.entities.Publisher;

public interface PublisherServices {

	//restituisce tutti i publisher
	// i metodi di un interfaccia sono tutti public
	
	List <Publisher> findAll();
	
	
	//Aggiungo metodo che restituisce publisher di cui si conosce l'id
	Publisher findById(Integer id) throws Exception;
	
	
	//salva un nuovo publisher
	Publisher save(Publisher publisher) ;
	
	
	//Cancella un publisher di id specificato
	void deleteById(Integer id) throws Exception;
	
	//completare gli altri metodi crud
	
	Publisher updateById(Integer id, Publisher Publisher) throws Exception;
	
	//cerco un publisher con un determinato nome
	Publisher findByName(String name) throws Exception;
	
	
	/* service: specifica quali metodi devono essere implementati per gestire i dati relativi al Publisher. Questa classe viene poi implementata
	 * da una classe che fornirà la logica concreta per ciascun metodo
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 *
	 *
	 */
	
	
	
	
}
