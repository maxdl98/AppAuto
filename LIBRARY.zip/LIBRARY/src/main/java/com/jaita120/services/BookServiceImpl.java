package com.jaita120.services;

import java.util.HashSet;


import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jaita120.entities.Author;
import com.jaita120.entities.Book;
import com.jaita120.repositories.BookRepository;
import com.jaita120.entities.Publisher;





@Service
public class BookServiceImpl implements BookService{


	@Autowired 
	private BookRepository repository;

	@Autowired
	private BookRepository bRepository;

	@Autowired
	private AuthorServices aService;

	@Autowired
	private PublisherServices pService;




	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book findById(Integer id) throws Exception {
		Optional <Book> book = repository.findById(id);
		if(book.isPresent()) {
			return book.get();
		}

		throw new Exception ("The book with id " + id + "is not present");
	}


	//verifico che il publisher e l'insieme di autori non siano nulli
	@Override
	public Book save(Book book) throws Exception {
		//Estrazione dei dati da book
		Set<Author> authors = book.getAuthors();
		Publisher publisher = book.getPublisher();
		Publisher publisherOnDb = null;
		Author authorOnDb = null;
		Set<Author> authorsOnDb = new HashSet<>();

		//Il book dopo il salvataggio sul DB
		Book savedBook = null;

		// Verifico che il publisher e l'insieme di autori non siano nulli
		if (publisher != null && !authors.isEmpty()) {
			// Verifico se il nome del publisher sia presente sul database
			try { 
				publisherOnDb = pService.findByName(publisher.getName());
			}catch(Exception e) {

			}
			if (publisherOnDb == null) {
				// il publisher non esiste sul DB e devo inserirlo
				publisherOnDb = pService.save(publisher);
			} 
			// sostituisco in book il publisher con quello presente sul DB
			book.setPublisher(publisherOnDb);
			// Per ogni autore eseguo una procedura simile a quella di Publisher
			for (Author author: authors) {
				// Verifico se il nome e il cognome dell'autore sia presente sul database
				// Ipotizziamo per semplicità che non ci siano autori omonimi
				try {
					authorOnDb = aService.findByNameAndSurname(author.getName(), author.getSurname());

				}catch(Exception e) {

				}
				if (authorOnDb == null) {
					// l'author non esiste sul DB e devo inserirlo
					authorOnDb = aService.save(author);
				}
				// Aggiungo l'autore presente su DB nel set authorsOnDb
				authorsOnDb.add(authorOnDb);
			} // End for
			// sostituisco in book il set di autori con quello presente sul DB
			book.setAuthors(authorsOnDb);

			// Finalmente salvo il book sul database
			savedBook = bRepository.save(book);
			return savedBook;
		}
		throw new Exception("Can't create book without publisher and without authors");
	}


	@Override
	public void deleteById(Integer id) throws Exception {
		if(repository.existsById(id)) {
			repository.deleteById(id);
		}

		else {
			throw new Exception ("id not found");
		}

	}

	@Override
	public Book updateById(Integer id, Book book) throws Exception {

		if(repository.existsById(id)) {
			return repository.save(book);
		}
		else {
			throw new Exception("Book with id: " +id + "not exists");
		}
	} 




	@Override
	public Book findByTitle(String title) throws Exception {
		Optional <Book> book = repository.findByTitle(title);
		if(book.isPresent()) {
			return book.get();
		}

		throw new Exception ("The book with title " + title + "is not present");
	}



}
