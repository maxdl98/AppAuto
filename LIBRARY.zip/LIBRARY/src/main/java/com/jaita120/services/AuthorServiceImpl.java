package com.jaita120.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jaita120.entities.Author;
import com.jaita120.repositories.AuthorRepository;
@Service
public class AuthorServiceImpl implements AuthorServices {
	
	@Autowired
	private AuthorRepository repository;

	@Override
	public List<Author> findAll() {
		
		return(List <Author>)repository.findAll();
		
		
	}

	@Override
	public Author findById(Integer id) throws Exception {
		Optional <Author> optAuthor = repository.findById(id);
		if(optAuthor.isPresent()) {
			return optAuthor.get();
		}
		
		throw new Exception ("L'autore con id" + id + "non esiste");
	}

	@Override
	public Author save(Author autore) {
		return repository.save(autore);
	}

	@Override
	public void deleteById(Integer id) throws Exception {
		if(repository.existsById(id)) {
			repository.deleteById(id);
			
		}else {
			throw new Exception("id not found");
		}
		
	}

	@Override
	public Author updateById(Integer id, Author Author) throws Exception {
		if(repository.existsById(id)) {
			return repository.save(Author);
		}
		else {
			throw new Exception("L'autore con tale id" + id + "non è stato trovato");
		}
	}

	@Override
	public Author findByNameAndSurname(String name, String surname) throws Exception {
		Optional<Author> optAuthor = repository.findByNameAndSurname(name, surname);
		if (optAuthor.isPresent()) {
			return optAuthor.get();
		}
		throw new Exception("Author with name " + name + " and surname " + surname + " not exists");
	}
	}


