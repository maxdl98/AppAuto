package com.jaita120.services;
//questa interfaccia definisce i metodi che descrivono la logica dell'applicazione

import java.util.List;





import com.jaita120.entities.Book;

public interface BookService {

List <Book> findAll();
	
	
	//Aggiungo metodo che restituisce book di cui si conosce l'id
	Book findById(Integer id) throws Exception;
	
	
	//salva un nuovo book
	Book save(Book book) throws Exception ;
	
	
	//Cancella un book di id specificato
	void deleteById(Integer id) throws Exception;
	
	//completare gli altri metodi crud
	
	Book updateById(Integer id, Book Book) throws Exception;
	
	//trova il libro con il titolo specificato
	
	Book findByTitle(String title) throws Exception;
	
	

	
	
	
}
