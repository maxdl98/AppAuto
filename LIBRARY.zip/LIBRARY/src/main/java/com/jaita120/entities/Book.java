package com.jaita120.entities;

import java.math.BigDecimal;






import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.HashSet;

// entity, significa che questa classe è un entita JPA, cioè una classe che può essere mappata a una tabella nel database
@Entity
@Table(name = "books") //specifica il nome della tabella del database a cui questa entità è mappata
public class Book {
	// con id si indica la chiave primaria, e generated value(..) significa che il valore del campo id sarà generato automaticamente dal database, AUTOINCREMENT
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	//SPECIFICA CHE LA COLONNA TITLE NON PUò ESSERE NULLA, E DEVE ESSERE UNICA
	@Column(nullable = false, unique = true)
	private String title;
	
	@Column(nullable = false)
	private String genre;
	
	//SPECIFICA CHE LE CIFRE IN TOTALE DEVONO ESSERE 6, CON DUE DECIMALI 
	@Column(nullable = false, precision = 6, scale = 2)
	private BigDecimal price;
	
	//Attributo aggiunto per l'associazione 1 a molti con publisher 
	@ManyToOne(fetch = FetchType.EAGER) //indica che i dati del publisher saranno caricati quando necessario(fecthtupe.LAZY)
	@JoinColumn(name = "id_publisher", //ID_PUBLISHER SPECIFICA LA COLONNA DI JOIN E LA COLONNA A CUI FA RIFERIMENTO E "ID" NELLA TABELLA PUBLISHER
	      referencedColumnName = "id")
	private Publisher publisher;
	
	
	
	//Attributo aggiunto per l'associazione molti a molti con author
	
	
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.MERGE) 
	@JoinTable(name = "authors_books",  // NOME DELLA NUOVA TABELLA, IN CUI VOGLIAMO INSERIRE GLI AUTORI E I LIBRI, ASSOCIAZIONE MOLTI A MOLTI
	   joinColumns = {  
	  @JoinColumn(name = "id_book",  //ID_BOOK SI SPECIFICA IL NOME DELLA TABELLA DA UNIRE  
	  referencedColumnName = "id")  //NOME EFFETTIVO DELL'ID PRESENTE NELLA TABELLA BOOKS
	 },  
	   inverseJoinColumns = {  
	  @JoinColumn(name = "id_author",  
	  referencedColumnName = "id") 
	 })
	
	private Set <Author> authors = new HashSet <>();

	
	
	/*------------------------- Methods Section -----------------------*/
	
	public Set<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	public Publisher getPublisher() {
		return publisher;
	}
	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	
	public void addAuthor(Author author) {
		authors.add(author);
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", genre=" + genre + ", price=" + price + "]";
	}

}
