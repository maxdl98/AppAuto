package com.jaita120.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jaita120.entities.Author;
@Repository
public interface AuthorRepository extends CrudRepository <Author,Integer> {

	Optional<Author> findByNameAndSurname(String name, String surname);

	
}
