package com.jaita120.repositories;

import java.util.Optional;




import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.jaita120.entities.Book;
@Repository
public interface BookRepository extends CrudRepository<Book,Integer> {
Optional <Book> findByTitle (String title);


}
