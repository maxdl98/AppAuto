package com.jaita120.repositories;

import java.util.Optional;


import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.jaita120.entities.Publisher;
//importa l'entità

//integer è il tipo della chiave primaria
@Repository
public interface PublisherRepository extends CrudRepository <Publisher, Integer>{

	Optional <Publisher> findByName(String name);
	
	
}

/*
import org.springframework.data.repository.CrudRepository: Importa l'interfaccia "CrudRepository" di Spring Data. Questa interfaccia
fornisce i metodi CRUD(CREATE, READ, UPDATE, DELETE) PER LA GESTIONE DELL'ENTITà 


import org.springframework.stereotype.Repository: Importa l'annotazione @Repository di Spring. 
Questa annotazione viene utilizzata per indicare che l'interfaccia è un componente di accesso ai dati.


*/