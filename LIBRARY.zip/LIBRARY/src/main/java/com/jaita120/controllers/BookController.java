package com.jaita120.controllers;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jaita120.entities.Book;
import com.jaita120.services.BookService;

@RestController
@RequestMapping ("/api/v1")
//
public class BookController {
	
	@Autowired
	private BookService service;
	
	//http://localhost:8080/api/v1/books/by-title/title
	@GetMapping("/books/by-title/{title}")
	public ResponseEntity<?> findByTitle(@PathVariable String title) {
		try {
			return new ResponseEntity <>(service.findByTitle(title), HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity <>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	//http://localhost:8080/api/v1/books/by-id/id
//vanno in conflitto id e title, 
	
	@GetMapping("/books/by-id/{id}")
	public ResponseEntity<?> findById(@PathVariable Integer id) {
		try {
			return new ResponseEntity <>(service.findById(id), HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity <>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	//http://localhost:8080/api/v1/books/id
	@DeleteMapping("/books/{id}")
	public ResponseEntity<?> deleteById(@PathVariable Integer id){
		try {
			service.deleteById(id);
			return new ResponseEntity<>("Il libro con id" +id + "è stato cancellato", HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	// http://localhost:8080/api/v1/books
		@PostMapping("/books")
		public ResponseEntity<?> save(@RequestBody Book book) {
			try {
				return new ResponseEntity<>(service.save(book), HttpStatus.OK);
			} catch(Exception e) {
				return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
			}
		}
	
		//http://localhost:8080/api/v1/books/id
	@PutMapping("/books/{id}")
	public ResponseEntity<?>updateById(@PathVariable Integer id, @RequestBody Book book){ //inserire id anche sul body
		try {
			return new ResponseEntity<>(service.updateById(id, book), HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	
}
