package com.jaita120.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jaita120.entities.Author;
import com.jaita120.services.AuthorServices;

@RestController
@RequestMapping("/api/v1")


public class AuthorController {

@Autowired
private AuthorServices service;

//http://localhost:8080/api/v1/authors/id

@GetMapping("/authors/{id}")
public ResponseEntity<?> findById(@PathVariable Integer id){
	try {
		return new ResponseEntity <>(service.findById(id), HttpStatus.OK);
		
	}catch(Exception e) {
		return new ResponseEntity <>(e.getMessage(), HttpStatus.NOT_FOUND);
	}
}

//http://localhost:8080/api/v1/authors
@PostMapping("/authors")
public ResponseEntity<?>save(@RequestBody Author autore){
	return new ResponseEntity<>(service.save(autore), HttpStatus.OK);
}

//http://localhost:8080/api/v1/authors
@GetMapping("/authors")

public ResponseEntity<?>findall(){
	List <Author> autori = service.findAll();
	if(!autori.isEmpty()) {
		return new ResponseEntity<>(autori,HttpStatus.OK);
	}
	
	else {
		return new ResponseEntity<>("Non ci sono attori", HttpStatus.OK);
	}
	
}

//http://localhost:8080/api/v1/authors/id

@DeleteMapping("/authors/{id}")
public ResponseEntity<?>deleteById(@PathVariable Integer id){
	try {
		service.deleteById(id);
		return new ResponseEntity<>("L'autore con id " + id + "è stato eliminato", HttpStatus.OK);
	}catch(Exception e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}
}

//http://localhost:8080/api/v1/authors/id
@PutMapping("/authors/{id}")
public ResponseEntity<?>updateById(@PathVariable Integer id, @RequestBody Author Author){
	try {
		return new ResponseEntity<>(service.updateById(id, Author), HttpStatus.OK);
	}catch(Exception e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}
}














	
	
}
