package com.jaita120.controllers.dto;

import java.math.BigDecimal;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor


public class BookPublisherAuthorsDto {
private String title;
private String genre;
private BigDecimal price;
private Set<Integer> AuthorsId;
private Integer PublisherId;

//posso gestire i controller in modo più semplice
}
