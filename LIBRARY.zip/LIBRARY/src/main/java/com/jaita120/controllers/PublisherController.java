package com.jaita120.controllers;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jaita120.entities.Publisher;
import com.jaita120.services.PublisherServices;

@RestController
@RequestMapping("/api/v1")

public class PublisherController {

	@Autowired
	private PublisherServices service ;

    // creiamo istanza di PublisherService, perchè alla fine lo va a prendere da implementazione con l'ereditarietà di java
	//API per ottenere tutti i publisher
	//http://localhost:8080/api/v1/publishers //qualcuno può fare una richiesta attraverso questa API

	@GetMapping("/publishers")
	/*public List <Publisher> findAll(){
		return service.findAll();
	} */

	public ResponseEntity<?> findAll() {
		List <Publisher> publishers = service.findAll();
		if(!publishers.isEmpty()) {
			return new ResponseEntity<>(publishers,HttpStatus.OK);
		} else {
			return new ResponseEntity<>("No publisher found",HttpStatus.OK);
		}
	}
	
	
	

	//API per ottenere tutti i publisher
	//http://localhost:8080/api/v1/publishers/1 //qualcuno può fare una richiesta attraverso questa API

	@GetMapping("/publisher/{id}")
	public ResponseEntity<?> findById(@PathVariable Integer id){ //scrivo path variable perchè specifico che l'id lo trova all'interno della chiamata
		try {
			return new ResponseEntity<>(service.findById(id), HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);

		}
	}
	
	
	//API per salvare un publisher 
	//http://localhost:8080/api/v1/authors
	
	@PostMapping("/publishers") //questi dati devono passare nel body della richiesta, i dati si trovano nel body della richiesta
	
	public ResponseEntity<?> save(@RequestBody Publisher publisher){
		return new ResponseEntity(service.save(publisher), HttpStatus.OK);
	}
	
	
	
	
	
	/*api per cancellare un publisher
	http://localhost:8080/api/v1/publishers/id

	
	
	
	
	*/
	
	@DeleteMapping("/publishers/{id}")
	public ResponseEntity<?> deleteById(@PathVariable Integer id){ //scrivo path variable perchè specifico che l'id lo trova all'interno della chiamata
		try {
			service.deleteById(id);
			return new ResponseEntity<>("Publisher with id " + id + "deleted" , HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);

		}
	}
	
	
	//aggiorna il publisher con id specificato
	//api per cancellare un publisher
	//http://localhost:8080/api/v1/books/id
	
	@PutMapping("/publishers/{id}")
	public ResponseEntity<?> updateById(@PathVariable Integer id, @RequestBody Publisher publisher){ //scrivo path variable perchè specifico che l'id lo trova all'interno della chiamata
		try {
			
			return new ResponseEntity<>(service.updateById(id,publisher), HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);

		}
	}




}
